<?php
global $essbof_options_structure;
if (!class_exists('ESSBOptionsStructureHelperShared') && defined('ESSB3_VERSION')) {
	include_once (ESSB3_PLUGIN_ROOT . 'lib/core/options/essb-options-structure-shared.php');

}

if (!class_exists('ESSBOptionsStructureHelperShared')) { return; }


$essbof_options_structure = new ESSBOptionsStructureHelperShared();
$essbof_options_structure->tab('settings', __('Optin forms in content', 'easy-optin-forms'), __('Optin forms in content', 'easy-optin-forms'));

$essbof_options_structure->menu_item('settings', 'settings', __('Settings', 'easy-optin-forms'), 'default');

$essbof_options_structure->field_switch('settings', 'settings', 'of_posts', __('Display on posts', 'easy-optin-forms'), __('Automatically display comments on posts.', 'easy-optin-forms'), '', __('Yes', 'easy-optin-forms'), __('No', 'easy-optin-forms'));
$essbof_options_structure->field_switch('settings', 'settings', 'of_pages', __('Display on pages', 'easy-optin-forms'), __('Automatically display comments on pages.', 'easy-optin-forms'), '', __('Yes', 'easy-optin-forms'), __('No', 'easy-optin-forms'));
$essbof_options_structure->field_select('settings', 'settings', 'of_design', __('Template of optin form', 'easy-facebook-comments'), __('Choose the design of optin forms that you wish to use for automatically generated forms', 'easy-facebook-comments'), essb_optin_designs());

$essbof_options_structure->field_switch('settings', 'settings', 'of_creditlink', __('Include credit link', 'easy-optin-forms'), __('Include tiny credit link below your comments box to allow others know what you are using to generate Facebook Comments. Activate this option to show your appreciation for our efforts.', 'easy-optin-forms'), '', __('Yes', 'easy-optin-forms'), __('No', 'easy-optin-forms'));



?>