if (essbViewsCacheL10n.valid) {
	jQuery.ajax({type:"GET",url:essbViewsCacheL10n.admin_ajax_url,data:"postviews_id="+essbViewsCacheL10n.post_id+"&action=postviews",cache:!1});
}

// counter loading script with ajax
jQuery(document).ready(function($){
	
	jQuery.fn.essb_get_views = function(){
		return this.each(function(){
			var post_self_count_id = $(this).attr("data-essb-postid") || "";
			var root = $(this).find(".essb_links_list");
			// view counters with ajax load only
			var view_count_element = root.find('.essb_viewcount.essb_viewcount_ajax');
			
			if (view_count_element.length) {
				var callback_address = essbViewsCacheL10n.admin_ajax_url + '?postviews_id=' + post_self_count_id+'&action=getpostviews';
				console.log(callback_address);
				$.getJSON(callback_address).done(function(data){
					
					var views = data['views'] ? data['views'] : '0';			
					$(view_count_element).find(".essb_views_number").text(views);
				});
			}

		});
	}
	
	$('.essb_links').essb_get_views();
});