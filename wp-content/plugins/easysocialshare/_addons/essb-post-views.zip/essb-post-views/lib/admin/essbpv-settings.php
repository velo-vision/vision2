<?php

global $essbpv_options_structure, $essb3pv_options;

$first_tab = $essbpv_options_structure->first_tab();
global $current_tab;
$current_tab = (empty ( $_REQUEST ['tab'] )) ? $first_tab : sanitize_text_field ( urldecode ( $_REQUEST ['tab'] ) );

global $essb3pv_options;

$essb3pv_options = get_option(ESSB3_PV_OPTIONS_NAME);


$cache_plugin_message = "";
$tabs = $essbpv_options_structure->tabs;
$section = $essbpv_options_structure->sidebar_sections [$current_tab];
$options = $essbpv_options_structure->sidebar_section_options [$current_tab];
$tab_sections = array();

$settings_update = isset ( $_REQUEST ['settings-updated'] ) ? $_REQUEST ['settings-updated'] : '';
if ($settings_update == "true") {
	// printf('<div class="updated" style="padding: 10px;">%1$s</div>', __('Easy
	// Social Share Buttons options are saved!', ESSB3_TEXT_DOMAIN));
	printf ( '<div class="essb-information-box"><div class="icon"><i class="fa fa-info-circle"></i></div><div class="inner">%1$s</div></div>', __ ( 'Self-Hosted Short Url Add-on options are saved!' . $cache_plugin_message, 'easy-post-views' ) );
}


?>

<div class="wrap">

<div class="essb-title-panel">
	
<h3>Post Views Addon for Easy Social Share Buttons for WordPress</h3>
		<p>
			Version <strong><?php echo ESSB3_PV_VERSION;?></strong>. &nbsp;<strong><a
				href="http://codecanyon.net/item/easy-social-share-buttons-for-wordpress/6394476?ref=appscreo"
				target="_blank">Easy Social Share Buttons plugin homepage</a></strong>
		</p>
	</div>
	<div class="essb-tabs">

		<ul>
    <?php
				$is_first = true;
				foreach ( $tabs as $name => $label ) {
					$tab_sections = isset ( $essbpv_options_structure->sidebar_section_options [$name] ) ? $essbpv_options_structure->sidebar_section_options [$name] : array ();
					$hidden_tab = isset ( $tab_sections ['hide_in_navigation'] ) ? $tab_sections ['hide_in_navigation'] : false;
					if ($hidden_tab) {
						continue;
					}
					
					$options_handler = "essb_ssu";
					echo '<li><a href="' . admin_url ( 'admin.php?page=' . $options_handler . '&tab=' . $name ) . '" class="essb-nav-tab ';
					if ($current_tab == $name)
						echo 'active';
					echo '">' . $label . '</a></li>';
					$is_first = false;
				}
				
				?>
    </ul>

	</div>
	<div class="essb-clear"></div>

	<?php
	
		ESSBOptionsInterface::draw_form_start (true, 'essbpv_settings_group');
		
		ESSBOptionsInterface::draw_header ( $section ['title'], $section ['hide_update_button'], $section ['wizard_tab'] );
		ESSBOptionsInterface::draw_sidebar ( $section ['fields'] );
		ESSBOptionsInterface::draw_content ( $options, true, $essb3pv_options );
		
		ESSBOptionsInterface::draw_form_end ();
		
		ESSBOptionsFramework::register_color_selector ();
		?>
</div>