<?php

global $essbab_options_structure, $essb3ab_options;

$first_tab = $essbab_options_structure->first_tab();
global $current_tab;
$current_tab = (empty ( $_REQUEST ['tab'] )) ? $first_tab : sanitize_text_field ( urldecode ( $_REQUEST ['tab'] ) );


$essb3ab_options = get_option(ESSB3_AB_OPTIONS_NAME);


$cache_plugin_message = "";
$tabs = $essbab_options_structure->tabs;
$section = $essbab_options_structure->sidebar_sections [$current_tab];
$options = $essbab_options_structure->sidebar_section_options [$current_tab];
$tab_sections = array();

$settings_update = isset ( $_REQUEST ['settings-updated'] ) ? $_REQUEST ['settings-updated'] : '';
if ($settings_update == "true") {
	// printf('<div class="updated" style="padding: 10px;">%1$s</div>', __('Easy
	// Social Share Buttons options are saved!', ESSB3_TEXT_DOMAIN));
	printf ( '<div class="essb-information-box"><div class="icon"><i class="fa fa-info-circle"></i></div><div class="inner">%1$s</div></div>', __ ( 'Social A/B add-on options are saved!' . $cache_plugin_message, 'easy-post-views' ) );
}


?>

<div class="wrap essb-settings-wrap">

	<div class="essb-tabs">
		<div class="essb-tabs-title">
			<div class="essb-tabs-version">
				<div class="essb-logo essb-logo32"></div>
				<div class="essb-text-afterlogo">
					<h3>Social A/B - Add-on for Easy Social Share Buttons for WordPress</h3>
					<p>
						Version <strong><?php echo ESSB3_AB_VERSION;?></strong>. &nbsp;<strong><a
							href="http://codecanyon.net/item/easy-social-share-buttons-for-wordpress/6394476?ref=appscreo"
							target="_blank">Easy Social Share Buttons plugin homepage</a></strong>
					</p>
					
				</div>
			</div>
			<div class="essb-title-panel-buttons">
	</div>
		</div>
		<ul>
    <?php
				$is_first = true;
				$tab_has_nomenu = false;
				foreach ( $tabs as $name => $label ) {
					$tab_sections = isset ( $essb_sidebar_sections [$name] ) ? $essb_sidebar_sections [$name] : array ();
					//print_r($tab_sections);
					$hidden_tab = isset ( $tab_sections ['hide_in_navigation'] ) ? $tab_sections ['hide_in_navigation'] : false;
					if ($hidden_tab) {
						continue;
					}
					
					$icon = isset ( $tab_sections ['icon'] ) ? $tab_sections ['icon'] : '';
					$align = isset($tab_sections['align']) ? $tab_sections['align'] : '';
					
					if ($icon == '') { $icon = 'ti-brush-alt'; }
					
					$options_handler = ($is_first) ? "essb_ab" : 'essb_redirect_' . $name;
					echo '<li '.($align == 'right' ? 'class="tab-right"' : '').'><a href="' . admin_url ( 'admin.php?page=' . $options_handler . '&tab=' . $name ) . '" class="essb-nav-tab ';
					if ($current_tab == $name)
						echo 'active';
					echo '">' . ($icon != '' ? '<i class="' . $icon . '"></i>' : '') . $label . '</a></li>';
					$is_first = false;
					
					if ($current_tab == $name) {
						$tab_has_nomenu = isset ( $tab_sections ['hide_menu'] ) ? $tab_sections ['hide_menu'] : false;
					}
				}
				
				?>
    </ul>

	</div>




	<div class="essb-clear"></div>

	<?php
	
		ESSBOptionsInterface::draw_form_start (true, 'essbab_settings_group');
		
		ESSBOptionsInterface::draw_sidebar ( $section ['fields'] );
		ESSBOptionsInterface::draw_header ( $section ['title'], $section ['hide_update_button'], $section ['wizard_tab'] );
		ESSBOptionsInterface::draw_content ( $options, true, $essb3ab_options );
		
		ESSBOptionsInterface::draw_form_end ();
		
		ESSBOptionsFramework::register_color_selector ();
		?>
</div>